/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yrn101
 */
public class Hw1p3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double number1=Double.parseDouble(args[0]); //first number from commandline argument
        System.out.println(args[0]);
        
        double number2=Double.parseDouble(args[1]); //second number from commandline argument
        System.out.println(args[1]);
        
        double product=number1*number2;
        System.out.println("product is "+product); //print product
    }
    
}
